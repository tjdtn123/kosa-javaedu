package emp;

public interface Bonus {
	public abstract void incentive(int pay);
}
