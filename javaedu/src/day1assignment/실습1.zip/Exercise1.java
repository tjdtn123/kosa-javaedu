package day1assignment;

public class Exercise1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a;
		int b;
		int c;		
		int sum;
		int avg;
		
		a = 10;
		b = 25;
		c = 33;
		
		sum = a+b+c;
		avg = sum/3;
		
		System.out.println("합계 : "+ sum);
		System.out.println("평균 : "+ avg);
		
		
		

	}

}
