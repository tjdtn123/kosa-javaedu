package day1assignment;

public class Exercise3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char name1;
		char name2;
		char name3;
		
		name1 = '이';
		name2 = '성';
		name3 = '수';
		
		System.out.print(name1);
		System.out.print(name2);
		System.out.print(name3);

	}

}
