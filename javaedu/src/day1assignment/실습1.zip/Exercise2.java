package day1assignment;

public class Exercise2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a;
		int b;		
		int share;
		int rest;
		
		a = 35;
		b = 10;
		
		share = a/b;
		rest = a%b;
		
		System.out.println(a + " 를 " + b + " 으로 나눈 결과 몫은 " + share + " 이고 나머지는 " + rest + "입니다." );
		
		

	}

}
