package day3;

public class ForLab5 {

	public static void main(String[] args) {
		
		int num1 = (int)(Math.random() * 8) + 3;
		int num2 = (int)(Math.random() * 4) + 1;
		
		switch(num2) {
		case 1 :
			for(int i=1; i <= num1; i++) {
				System.out.print("*");
			}
			break;
		case 2 :
			for(int i=1; i <= num1; i++) {
				System.out.print("$");
			}
			break;
		default :
			for(int i=1; i <= num1; i++) {
				System.out.print("#");
			}							
		}
		

	}

}
