package day11;

import java.util.Random;
import day6.MethodTest9;
public class LottoMachine {
	private int[] nums;
	
	LottoMachine(){
		
	}
	
	public void createLottoNums() {
		int[] lotnum = new int[6];
		
		for(int i=0; i<6; i++) {
			lotnum[i] = new Random().nextInt(19)+1;
		}
		nums = lotnum;
	}
	public void checkLottoNums() throws DuplicateException{
		int cnt;
		int checkNum = 0;
		
			for(int i=0; i<6; i++) {
			cnt = 0;
			checkNum = nums[i];
				for(int j=0; j<6; j++) {
					if(checkNum == nums[j]) 
						cnt++;							
				}					
				if(cnt>1)
					throw new DuplicateException();				
			}		
	}
	public int[] getNums() {
		return nums;
	}
}
