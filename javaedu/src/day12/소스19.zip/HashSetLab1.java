package day12;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;

public class HashSetLab1 {

	public static void main(String[] args) {
		HashSet<Integer> nums = new HashSet<>();		
		Random ran = new Random();	
		
		for(int i=1; i<=10; i++) {			
			if(nums.add(ran.nextInt(19)+10) == false) {
				i--;
				System.out.println("중복");
			}			
		}
	
		Iterator<Integer> iterator = nums.iterator();
		while (iterator.hasNext()) {
			int num = iterator.next();
			System.out.println(num);
		}
		System.out.println(nums);
	}

}
