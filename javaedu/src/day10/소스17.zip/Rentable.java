package day10;

public interface Rentable {
	void rent();
}
